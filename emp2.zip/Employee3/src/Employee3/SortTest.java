package Employee3;

import java.util.*;

public class SortTest
{
public static void main(String args[])
{
new SortTest();
}



public SortTest()
{
//fill some employee objects
ArrayList list = new ArrayList();
list.add(new Employee3("chandana","mittapally",12,10.0000,"cs"));
list.add(new Employee3("Lahari","mittapally",11,12.0000,"cs"));
list.add(new Employee3("Lohitha","kethineni",14,14.0000,"it"));
list.add(new Employee3("chandana","mittpali",17,11.0000,"aero"));
list.add(new Employee3("Sravanthi","chitamaneni",14,13.0000,"csbs"));
list.add(new Employee3("Ravali","vasala",15,11.0000,"cs"));
list.add(new Employee3("Vineela","adepu",17,15.0000,"mechanical"));
list.add(new Employee3("srujana","thuna",18,11.0000,"aero"));
list.add(new Employee3("Vinya","adepu",18,15.0000,"mechanical"));
list.add(new Employee3("sanju","akkati",19,11.0000,"civil"));



System.out.println("Initial List :");
print(list);



Collections.sort(list,new SortyByDepartment());
System.out.println("Sorted List By Department:");
print(list);
System.out.println("n");



Collections.sort(list,new SortyBySalary());
System.out.println("Sorted List By Salary:");
print(list);



}



public void print(ArrayList list)
{
Iterator it = list.iterator();
while(it.hasNext())
{
Employee3 emp = (Employee3) it.next();
System.out.println(emp);
}
}
}