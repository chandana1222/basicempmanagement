package Employee3;

class Employee3
{
public String fname;
public String lname;
public int age;
public double salary;
public String department;




public Employee3(String fname,String lname,int age,double salary,String department )
{
this.fname = fname;
this.lname = lname;
this.age=age;
this.salary = salary;
this.department = department;
}



public String toString()
{
return this.fname +", "+this.lname+", "+this.age +", "+this.salary+", "+this.department;
}
}



