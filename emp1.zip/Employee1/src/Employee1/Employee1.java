package Employee1;

import java.util.Scanner;

import Employee1.Employee1;
public class Employee1 {
String fname;
String lname;
String deptname;
float salary;
float age;
String department;
static int numberofobjects=0;
Employee1(){
fname="";
lname="";
deptname="";
salary=0;
age=0;
}
Employee1(String fname,String lname,String deptname,float salary,float age ){
this.fname=fname;
this.lname=lname;
this.deptname=deptname;
this.salary=salary;
this.age=age;
numberofobjects++;
}
public void display(){
System.out.println("Employee fname :"+fname);
System.out.println("Employee lname: "+lname);
System.out.println("Employee Department: "+deptname);
System.out.println("Employee Salary :"+salary);
System.out.println("Employee age :"+age);
}
public static void main(String[] args){
int n=0;
Scanner sc=new Scanner(System.in);
System.out.print("How many employees you want to enter :");
n=sc.nextInt();
Employee1[] ob=new Employee1[n];
for(int i=0;i<n;i++){
sc= new Scanner(System.in);
System.out.println("Enter fname of employee "+(i+1)+" :");
String fname=sc.nextLine();
System.out.println("Enter lname of employee "+(i+1)+" :");
String lname= sc.nextLine();
System.out.println("Enter dept name of employee "+(i+1)+" :");
String deptname=sc.nextLine();
System.out.println("Enter salary of employee "+(i+1)+" :");
float salary = sc.nextFloat();
System.out.println("Enter age of employee "+(i+1)+" :");
float age = sc.nextFloat();
ob[i]=new Employee11(fname,lname,deptname,salary,age);
System.out.println("\nNumber of Objects : "+numberofobjects);

}
for(int i=0;i<n;i++)
{
ob[i].display();
}
}
}